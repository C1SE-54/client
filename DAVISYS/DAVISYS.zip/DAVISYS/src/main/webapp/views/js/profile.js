// show - close dialog update post
/*const showButton_updatePost = document.getElementById('showButton_updatePost');*/
/*const favDialog_updatePost = document.getElementById('favDialog_updatePost');
const close_updatePost = document.getElementById('close2');
const container = document.querySelector(".modal-open");

close_updatePost.addEventListener('click', () => {
    favDialog_updatePost.style.display = 'none';
});*/
/*showButton_updatePost.addEventListener('click', () => {
    favDialog_updatePost.showModal();
});*/