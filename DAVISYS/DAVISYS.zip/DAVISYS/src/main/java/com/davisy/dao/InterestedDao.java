package com.davisy.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.davisy.entity.Interested;

public interface InterestedDao extends JpaRepository<Interested, Integer> {

}
